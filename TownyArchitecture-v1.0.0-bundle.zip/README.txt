=== TownyArchitecture v1.1.0 ===
Chunk-Based City Architecture & mcMMO Integration for Paper 1.20+

NEW FEATURES IN v1.1.0:
1. Strict Permission & mcMMO Verification:
   - Only town Mayor or Assistant can start building projects.
   - Players without required mcMMO levels (or fresh empty accounts) CANNOT build or start projects.
2. Chunk-Based System:
   - Buildings occupy designated 1x1, 1x2, or 2x2 chunks (Wonders).
   - Town Mayor marks plots using: /plot set build
   - Automatic geometry scanning verifies free contiguous chunk plots.
   - Designated chunks extend from world min height (-64) to max height (320).
3. Real-Time HUD on Chunks in Progress:
   - BossBar and Action Bar show live required vs placed block counts.
   - /builds info shows detailed breakdown progress.
4. Parallel Construction:
   - Blocks placed in a chunk only count towards that specific building.

Installation:
1. Put TownyArchitecture-1.1.0.jar into your server "plugins" folder.
2. Ensure Towny and mcMMO are installed.
3. Restart server or run /plugman load TownyArchitecture.
